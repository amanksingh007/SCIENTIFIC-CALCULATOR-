# SCIENTIFIC-CALCULATOR
it is a scientific calcuator developed using JAVA and NETBEANS IDE.
